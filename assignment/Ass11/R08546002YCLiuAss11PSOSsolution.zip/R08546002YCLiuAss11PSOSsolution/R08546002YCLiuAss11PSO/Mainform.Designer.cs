﻿namespace R08546002YCLiuAss11PSO
{
    partial class Mainform
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Mainform));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.labMessage = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbOpen = new System.Windows.Forms.ToolStripButton();
            this.btnNewProblem = new System.Windows.Forms.ToolStripButton();
            this.spcMain = new System.Windows.Forms.SplitContainer();
            this.spcSecond = new System.Windows.Forms.SplitContainer();
            this.spcThird = new System.Windows.Forms.SplitContainer();
            this.MainChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btnCreatePSOSolver = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabObjective = new System.Windows.Forms.TabPage();
            this.tabSolutionInfo = new System.Windows.Forms.TabPage();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnRunEnd = new System.Windows.Forms.Button();
            this.btnRunOneIteration = new System.Windows.Forms.Button();
            this.cbxUpdate = new System.Windows.Forms.CheckBox();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.labSoFarTheBestSolution = new System.Windows.Forms.Label();
            this.labSoFarTheShortestLength = new System.Windows.Forms.Label();
            this.rtbSoFarTheBestSolution = new System.Windows.Forms.RichTextBox();
            this.theGrid = new System.Windows.Forms.PropertyGrid();
            this.ltbSolutions = new System.Windows.Forms.ListBox();
            this.ckxShowSolutions = new System.Windows.Forms.CheckBox();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.progressbar = new System.Windows.Forms.ToolStripProgressBar();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spcMain)).BeginInit();
            this.spcMain.Panel2.SuspendLayout();
            this.spcMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spcSecond)).BeginInit();
            this.spcSecond.Panel1.SuspendLayout();
            this.spcSecond.Panel2.SuspendLayout();
            this.spcSecond.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spcThird)).BeginInit();
            this.spcThird.Panel1.SuspendLayout();
            this.spcThird.Panel2.SuspendLayout();
            this.spcThird.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MainChart)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabSolutionInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Purple;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1122, 27);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem});
            this.fileToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(47, 23);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.openToolStripMenuItem.Text = "Open";
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labMessage,
            this.toolStripStatusLabel1,
            this.progressbar,
            this.toolStripProgressBar1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 661);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1122, 33);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "Time Spent";
            // 
            // labMessage
            // 
            this.labMessage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labMessage.Name = "labMessage";
            this.labMessage.Size = new System.Drawing.Size(903, 27);
            this.labMessage.Spring = true;
            this.labMessage.Text = "Time Spent";
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbOpen,
            this.btnNewProblem});
            this.toolStrip1.Location = new System.Drawing.Point(0, 27);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1122, 27);
            this.toolStrip1.TabIndex = 3;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbOpen
            // 
            this.tsbOpen.Image = ((System.Drawing.Image)(resources.GetObject("tsbOpen.Image")));
            this.tsbOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbOpen.Name = "tsbOpen";
            this.tsbOpen.Size = new System.Drawing.Size(71, 24);
            this.tsbOpen.Text = "Open";
            this.tsbOpen.Click += new System.EventHandler(this.tsbOpen_Click);
            // 
            // btnNewProblem
            // 
            this.btnNewProblem.Image = ((System.Drawing.Image)(resources.GetObject("btnNewProblem.Image")));
            this.btnNewProblem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNewProblem.Name = "btnNewProblem";
            this.btnNewProblem.Size = new System.Drawing.Size(128, 24);
            this.btnNewProblem.Text = "New Problem";
            this.btnNewProblem.Click += new System.EventHandler(this.btnNewProblem_Click);
            // 
            // spcMain
            // 
            this.spcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spcMain.Location = new System.Drawing.Point(0, 54);
            this.spcMain.Name = "spcMain";
            // 
            // spcMain.Panel1
            // 
            this.spcMain.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            // 
            // spcMain.Panel2
            // 
            this.spcMain.Panel2.Controls.Add(this.spcSecond);
            this.spcMain.Size = new System.Drawing.Size(1122, 607);
            this.spcMain.SplitterDistance = 277;
            this.spcMain.TabIndex = 4;
            // 
            // spcSecond
            // 
            this.spcSecond.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spcSecond.Location = new System.Drawing.Point(0, 0);
            this.spcSecond.Name = "spcSecond";
            // 
            // spcSecond.Panel1
            // 
            this.spcSecond.Panel1.Controls.Add(this.spcThird);
            // 
            // spcSecond.Panel2
            // 
            this.spcSecond.Panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.spcSecond.Panel2.Controls.Add(this.splitContainer1);
            this.spcSecond.Size = new System.Drawing.Size(841, 607);
            this.spcSecond.SplitterDistance = 428;
            this.spcSecond.TabIndex = 0;
            // 
            // spcThird
            // 
            this.spcThird.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spcThird.Location = new System.Drawing.Point(0, 0);
            this.spcThird.Name = "spcThird";
            this.spcThird.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // spcThird.Panel1
            // 
            this.spcThird.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.spcThird.Panel1.Controls.Add(this.MainChart);
            // 
            // spcThird.Panel2
            // 
            this.spcThird.Panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.spcThird.Panel2.Controls.Add(this.tabControl1);
            this.spcThird.Size = new System.Drawing.Size(428, 607);
            this.spcThird.SplitterDistance = 230;
            this.spcThird.TabIndex = 0;
            // 
            // MainChart
            // 
            this.MainChart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            chartArea1.AxisX.Title = "Iteration";
            chartArea1.AxisY.Title = "Objective";
            chartArea1.Name = "ChartArea1";
            this.MainChart.ChartAreas.Add(chartArea1);
            this.MainChart.Dock = System.Windows.Forms.DockStyle.Fill;
            legend1.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
            legend1.Name = "Legend1";
            this.MainChart.Legends.Add(legend1);
            this.MainChart.Location = new System.Drawing.Point(0, 0);
            this.MainChart.Name = "MainChart";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Legend = "Legend1";
            series1.Name = "Iteration Average";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.Legend = "Legend1";
            series2.Name = "Iteration Best";
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series3.Legend = "Legend1";
            series3.Name = "So Far The Best";
            this.MainChart.Series.Add(series1);
            this.MainChart.Series.Add(series2);
            this.MainChart.Series.Add(series3);
            this.MainChart.Size = new System.Drawing.Size(428, 230);
            this.MainChart.TabIndex = 0;
            this.MainChart.Text = "chart1";
            title1.Name = "Title1";
            this.MainChart.Titles.Add(title1);
            // 
            // btnCreatePSOSolver
            // 
            this.btnCreatePSOSolver.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnCreatePSOSolver.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreatePSOSolver.Location = new System.Drawing.Point(12, 4);
            this.btnCreatePSOSolver.Name = "btnCreatePSOSolver";
            this.btnCreatePSOSolver.Size = new System.Drawing.Size(390, 30);
            this.btnCreatePSOSolver.TabIndex = 0;
            this.btnCreatePSOSolver.Text = "Create A PSO Solver";
            this.btnCreatePSOSolver.UseVisualStyleBackColor = false;
            this.btnCreatePSOSolver.Click += new System.EventHandler(this.btnCreatePSOSolver_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabObjective);
            this.tabControl1.Controls.Add(this.tabSolutionInfo);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(428, 373);
            this.tabControl1.TabIndex = 0;
            // 
            // tabObjective
            // 
            this.tabObjective.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabObjective.Location = new System.Drawing.Point(4, 27);
            this.tabObjective.Name = "tabObjective";
            this.tabObjective.Padding = new System.Windows.Forms.Padding(3);
            this.tabObjective.Size = new System.Drawing.Size(552, 347);
            this.tabObjective.TabIndex = 0;
            this.tabObjective.Text = "Objective";
            this.tabObjective.UseVisualStyleBackColor = true;
            // 
            // tabSolutionInfo
            // 
            this.tabSolutionInfo.Controls.Add(this.ltbSolutions);
            this.tabSolutionInfo.Controls.Add(this.ckxShowSolutions);
            this.tabSolutionInfo.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabSolutionInfo.Location = new System.Drawing.Point(4, 27);
            this.tabSolutionInfo.Name = "tabSolutionInfo";
            this.tabSolutionInfo.Padding = new System.Windows.Forms.Padding(3);
            this.tabSolutionInfo.Size = new System.Drawing.Size(420, 342);
            this.tabSolutionInfo.TabIndex = 1;
            this.tabSolutionInfo.Text = "Solution Info";
            this.tabSolutionInfo.UseVisualStyleBackColor = true;
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnReset.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(12, 40);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(390, 29);
            this.btnReset.TabIndex = 14;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnRunEnd
            // 
            this.btnRunEnd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnRunEnd.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRunEnd.Location = new System.Drawing.Point(12, 110);
            this.btnRunEnd.Name = "btnRunEnd";
            this.btnRunEnd.Size = new System.Drawing.Size(390, 27);
            this.btnRunEnd.TabIndex = 16;
            this.btnRunEnd.Text = "Run to End";
            this.btnRunEnd.UseVisualStyleBackColor = false;
            this.btnRunEnd.Click += new System.EventHandler(this.btnRunEnd_Click);
            // 
            // btnRunOneIteration
            // 
            this.btnRunOneIteration.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnRunOneIteration.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRunOneIteration.Location = new System.Drawing.Point(12, 75);
            this.btnRunOneIteration.Name = "btnRunOneIteration";
            this.btnRunOneIteration.Size = new System.Drawing.Size(390, 29);
            this.btnRunOneIteration.TabIndex = 15;
            this.btnRunOneIteration.Text = "Run One Iteration";
            this.btnRunOneIteration.UseVisualStyleBackColor = false;
            this.btnRunOneIteration.Click += new System.EventHandler(this.btnRunOneIteration_Click);
            // 
            // cbxUpdate
            // 
            this.cbxUpdate.AutoSize = true;
            this.cbxUpdate.Checked = true;
            this.cbxUpdate.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbxUpdate.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxUpdate.Location = new System.Drawing.Point(12, 143);
            this.cbxUpdate.Name = "cbxUpdate";
            this.cbxUpdate.Size = new System.Drawing.Size(256, 24);
            this.cbxUpdate.TabIndex = 17;
            this.cbxUpdate.Text = "Real-time Update Progress";
            this.cbxUpdate.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.splitContainer1.Panel1.Controls.Add(this.rtbSoFarTheBestSolution);
            this.splitContainer1.Panel1.Controls.Add(this.labSoFarTheBestSolution);
            this.splitContainer1.Panel1.Controls.Add(this.labSoFarTheShortestLength);
            this.splitContainer1.Panel1.Controls.Add(this.btnCreatePSOSolver);
            this.splitContainer1.Panel1.Controls.Add(this.btnRunOneIteration);
            this.splitContainer1.Panel1.Controls.Add(this.cbxUpdate);
            this.splitContainer1.Panel1.Controls.Add(this.btnReset);
            this.splitContainer1.Panel1.Controls.Add(this.btnRunEnd);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.theGrid);
            this.splitContainer1.Size = new System.Drawing.Size(409, 607);
            this.splitContainer1.SplitterDistance = 277;
            this.splitContainer1.TabIndex = 18;
            // 
            // labSoFarTheBestSolution
            // 
            this.labSoFarTheBestSolution.AutoSize = true;
            this.labSoFarTheBestSolution.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labSoFarTheBestSolution.Location = new System.Drawing.Point(7, 189);
            this.labSoFarTheBestSolution.Name = "labSoFarTheBestSolution";
            this.labSoFarTheBestSolution.Size = new System.Drawing.Size(202, 19);
            this.labSoFarTheBestSolution.TabIndex = 19;
            this.labSoFarTheBestSolution.Text = "So Far The Best Solution :  ";
            // 
            // labSoFarTheShortestLength
            // 
            this.labSoFarTheShortestLength.AutoSize = true;
            this.labSoFarTheShortestLength.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labSoFarTheShortestLength.Location = new System.Drawing.Point(8, 170);
            this.labSoFarTheShortestLength.Name = "labSoFarTheShortestLength";
            this.labSoFarTheShortestLength.Size = new System.Drawing.Size(218, 19);
            this.labSoFarTheShortestLength.TabIndex = 18;
            this.labSoFarTheShortestLength.Text = "So Far The Shortest Length : ";
            // 
            // rtbSoFarTheBestSolution
            // 
            this.rtbSoFarTheBestSolution.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rtbSoFarTheBestSolution.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbSoFarTheBestSolution.Location = new System.Drawing.Point(3, 211);
            this.rtbSoFarTheBestSolution.Name = "rtbSoFarTheBestSolution";
            this.rtbSoFarTheBestSolution.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
            this.rtbSoFarTheBestSolution.Size = new System.Drawing.Size(402, 104);
            this.rtbSoFarTheBestSolution.TabIndex = 20;
            this.rtbSoFarTheBestSolution.Text = "";
            // 
            // theGrid
            // 
            this.theGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.theGrid.Location = new System.Drawing.Point(0, 0);
            this.theGrid.Name = "theGrid";
            this.theGrid.Size = new System.Drawing.Size(409, 326);
            this.theGrid.TabIndex = 2;
            // 
            // ltbSolutions
            // 
            this.ltbSolutions.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ltbSolutions.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ltbSolutions.FormattingEnabled = true;
            this.ltbSolutions.HorizontalScrollbar = true;
            this.ltbSolutions.ItemHeight = 20;
            this.ltbSolutions.Location = new System.Drawing.Point(4, 20);
            this.ltbSolutions.Name = "ltbSolutions";
            this.ltbSolutions.ScrollAlwaysVisible = true;
            this.ltbSolutions.Size = new System.Drawing.Size(417, 324);
            this.ltbSolutions.TabIndex = 15;
            // 
            // ckxShowSolutions
            // 
            this.ckxShowSolutions.AutoSize = true;
            this.ckxShowSolutions.Checked = true;
            this.ckxShowSolutions.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckxShowSolutions.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ckxShowSolutions.Location = new System.Drawing.Point(3, 3);
            this.ckxShowSolutions.Name = "ckxShowSolutions";
            this.ckxShowSolutions.Size = new System.Drawing.Size(142, 22);
            this.ckxShowSolutions.TabIndex = 14;
            this.ckxShowSolutions.Text = "Show Solutions";
            this.ckxShowSolutions.UseVisualStyleBackColor = true;
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 27);
            // 
            // progressbar
            // 
            this.progressbar.Name = "progressbar";
            this.progressbar.Size = new System.Drawing.Size(200, 25);
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(0, 25);
            // 
            // Mainform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1122, 694);
            this.Controls.Add(this.spcMain);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Mainform";
            this.Text = "Assignment#11";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.spcMain.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spcMain)).EndInit();
            this.spcMain.ResumeLayout(false);
            this.spcSecond.Panel1.ResumeLayout(false);
            this.spcSecond.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spcSecond)).EndInit();
            this.spcSecond.ResumeLayout(false);
            this.spcThird.Panel1.ResumeLayout(false);
            this.spcThird.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spcThird)).EndInit();
            this.spcThird.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.MainChart)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabSolutionInfo.ResumeLayout(false);
            this.tabSolutionInfo.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbOpen;
        private System.Windows.Forms.ToolStripStatusLabel labMessage;
        private System.Windows.Forms.SplitContainer spcMain;
        private System.Windows.Forms.SplitContainer spcSecond;
        private System.Windows.Forms.SplitContainer spcThird;
        private System.Windows.Forms.Button btnCreatePSOSolver;
        private System.Windows.Forms.DataVisualization.Charting.Chart MainChart;
        private System.Windows.Forms.ToolStripButton btnNewProblem;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabObjective;
        private System.Windows.Forms.TabPage tabSolutionInfo;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.RichTextBox rtbSoFarTheBestSolution;
        private System.Windows.Forms.Label labSoFarTheBestSolution;
        private System.Windows.Forms.Label labSoFarTheShortestLength;
        private System.Windows.Forms.Button btnRunOneIteration;
        private System.Windows.Forms.CheckBox cbxUpdate;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnRunEnd;
        private System.Windows.Forms.PropertyGrid theGrid;
        private System.Windows.Forms.ListBox ltbSolutions;
        private System.Windows.Forms.CheckBox ckxShowSolutions;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripProgressBar progressbar;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
    }
}

